jQuery(window).load(function() {
/*global jQuery:false */
"use strict";
	
jQuery('.wpm_eleslider').owlCarousel({
    center: true,
    items:1,
    loop:true,
	autoplay: 'true',
	autoplayTimeout: 8000,
	nav:true,
	stagePadding: 0,
	navText:[],
    margin:0,
        dots: true,
        dotData: true,
        dotsData: true,
		
});
  
});